package com.example.arcs.essentials;

import javafx.geometry.Point2D;

import java.text.DecimalFormat;

public class Printer {
	public static void printPointCoordinates(String description, Point2D point) {
		System.out.println(description + " - X: " + point.getX() + ", Y: " + point.getY());
	}

	public static void printDouble(double value, String description) {
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		System.out.println(description + ": " + decimalFormat.format(value));
	}
	public static void printLine(OrthyLine line){
		System.out.println(line.toString());
	}
}
