package com.example.arcs.essentials;

import javafx.geometry.Point2D;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.util.ArrayList;
import java.util.List;

public class LineHandler {

	private OrthyLine line;
	private List<Point2D> linePoints = new ArrayList<>();

	public OrthyLine getLine() {
		return line;
	}

	public void setLine(OrthyLine line) {
		this.line = line;
	}

	public List<Point2D> getLinePoints() {
		return linePoints;
	}

	public void setLinePoints(List<Point2D> linePoints) {
		this.linePoints = linePoints;
	}

	public void resetLine(){
		this.line = null;
		this.linePoints.clear();
	}
	public void initLine(Pane drawingPane){
		line = new OrthyLine(linePoints.get(0), linePoints.get(1));
		line.getLine().setStrokeWidth(2);
		line.getLine().setStroke(Color.BLACK);
		drawingPane.getChildren().add(line.getLine());
		Printer.printLine(line);
	}
	public void drawPoint(Point2D p, Pane pane){
		Circle point = new Circle(p.getX(), p.getY(), 2, Color.BLACK);
		pane.getChildren().add(point);
	}
	public void handleMouseClick(MouseEvent event, Pane drawingPane){
		Point2D tempPoint = new Point2D(event.getX(), event.getY());
		linePoints.add(tempPoint);
		drawPoint(tempPoint, drawingPane);

	}
}
