package com.example.arcs.util;

import javafx.geometry.Point2D;
import javafx.scene.shape.Arc;
import javafx.scene.shape.CubicCurve;

import java.util.ArrayList;
import java.util.List;

public class OrthyArc {

	private List<Point2D> arcPoints = new ArrayList<>();

	private Arc arc;
	private CubicCurve cubicArc;

}
