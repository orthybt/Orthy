package com.example.arcs;

import com.example.arcs.essentials.LineHandler;
import com.example.arcs.essentials.ArcHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import java.io.File;
import java.nio.file.Paths;

public class ArcsController {
	//My Components
	ArcHandler arcHandler = new ArcHandler();
	LineHandler lineHandler = new LineHandler();
	//Components
	@FXML
	private ImageView imageView;
	@FXML
	private Button loadImageButton;
	@FXML
	private Button drawArcButton;
	@FXML
	private Button drawLineButton;
	@FXML
	private Button clearButton;
	@FXML
	private StackPane stackPane;
	@FXML
	private Pane imagePane;
	@FXML
	private Pane drawingPane;

	//Method declaration
	@FXML
	private void loadImage() {
		FileChooser fileChooser = new FileChooser();

		// Set the initial directory
		fileChooser.setInitialDirectory(new File("C:\\Users\\User\\Documents"));

		// Add file filters for images
		fileChooser.getExtensionFilters().addAll(
				new FileChooser.ExtensionFilter("All Images", "*.*"),
				new FileChooser.ExtensionFilter("JPG", "*.jpg"),
				new FileChooser.ExtensionFilter("PNG", "*.png"),
				new FileChooser.ExtensionFilter("BMP", "*.bmp"),
				new FileChooser.ExtensionFilter("GIF", "*.gif")
		);

		// Open the file dialog
		File file = fileChooser.showOpenDialog(null);

		if (file != null) {
			// Load and display the image
			Image image = new Image(Paths.get(file.getAbsolutePath()).toUri().toString());
			imageView.setImage(image);
		}
	}
	@FXML
	private void initStackPane() {
		if (!stackPane.getChildren().contains(imagePane)) {
			stackPane.getChildren().add(0, imagePane);
		}

		if (!stackPane.getChildren().contains(drawingPane)) {
			stackPane.getChildren().add(1, drawingPane);
		}
	}
	@FXML
	private void drawArc() {
		drawingPane.setOnMouseClicked(this::handleDrawArcButton);
	}
	@FXML
	private void drawLine(){
		drawingPane.setOnMouseClicked(this::handeDrawLineButton);
	}
	//Method initialization
	@FXML
	private void initialize() {
		initStackPane();
		// Set up event handling or any other initialization logic
		loadImageButton.setOnAction(event -> loadImage());
		drawArcButton.setOnAction(event -> drawArc());
		clearButton.setOnAction(event -> handleClearButton());
		drawLineButton.setOnAction(event -> drawLine());
	}
	private void handeDrawLineButton(MouseEvent event){
		if (lineHandler.getLinePoints().size() < 2) {
			lineHandler.handleMouseClick(event, drawingPane);
		}
		if (lineHandler.getLinePoints().size() == 2) {
			lineHandler.initLine(drawingPane);
			lineHandler.resetLine();
		}
	}
	private void handleDrawArcButton(MouseEvent event) {
		if(arcHandler.getArcPoints().size() < 2){
			arcHandler.handleMouseClick(event, drawingPane);
		}
		if(arcHandler.getArcPoints().size() == 2){
			arcHandler.initArc(drawingPane);
			arcHandler.resetArc();
		}
	}
	private void handleClearButton(){
		drawingPane.getChildren().clear();
	}
}
