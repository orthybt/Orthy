//package com.example.arcs.recycleBin;
//
//import javafx.geometry.Point2D;
//import javafx.scene.shape.Line;
//
//public class CircleUtil {
//
//	public static Point2D findCenter(Point2D p1, Point2D p2) {
//		// Implementation...
//	}
//
//	public static Point2D findTangentIntersection(Point2D p1, Point2D p2) {
//		// Implementation...
//	}
//
//	public static Point2D findLineIntersection(Line intLine, Line radius) {
//		// Implementation...
//	}
//}
